#ifndef _MCLIENT_H_
#define _MCLIENT_H_
/*#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> // for sleep()
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sstream>
*/
#include<sys/socket.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<netinet/in.h>
#include<unistd.h>
#include<fstream>
#include<sstream>
#include<sys/stat.h>
#include<string.h>
#include <stdlib.h>
#include <signal.h>
#include<csignal>
#include<time.h>
#include<climits>
#include<limits>
#include<iostream>
#define MSGBUFSIZE 2048
using namespace std;   
class mclient1{    
public:
    int mclient();
    struct timeval t_out;
	 struct sockaddr_in addr;
	char ip[INET_ADDRSTRLEN];

    mclient1();    //constructor.
    ~mclient1();   //destructor.
};

    
#endif



#ifndef _UDP_H_
#define _UDP_H_
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

#define MSGBUFSIZE 2048


class udp1{
public:

 int udp(int argc, char *argv[]);
 udp1();
    ~udp1();
};
#endif

#include "../header/UDP.h"
#include "../header/mclient.h"
int main(int argc, char *argv[])
{ int i=0;
    cout<<"Enter your choice\n 1.SERVER\n 2.CLIENT\n";
    cin>>i;
if(i==1){
     mclient1 c;
    c.mclient();
    c.~mclient1();
    }
   else if(i==2){ 
 udp1 s;
 s.udp(argc, argv);
 s.~udp1();
}
else 
   return 1;


return 0;
}


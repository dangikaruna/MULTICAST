#include "../header/mclient.h"

mclient1::mclient1() {}
int mclient1::mclient()
{
    const char *message1 = "--- sender is active ---";
    int i = 0, j = 0, g = 0, k = 0;
    int port;

    ifstream files;
    string line;
    files.open("../resource/con.cfg");
    while (getline(files, line))
    {
        istringstream sin(line.substr(line.find("=") + 1));
        if (line.find("port") != -1)
        {
            sin >> port;
        }
        else if (line.find("IP") != -1)
        {
            sin >> ip;
        }
    }

    inet_pton(AF_INET, ip, &(addr.sin_addr));

    inet_ntop(AF_INET, &(addr.sin_addr), ip, INET_ADDRSTRLEN);
    int arr[5];
    
    printf("how many groups need to be created?\n");
     loop1 :
     while (!(cin >> j)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Enter a number: ";
    }
    if(j==0){
    cout<<"group is not created so we need to enter valid number\n";
    goto loop1;}
    for (int k = 0; k < j; k++)
    {
        arr[k] = port;
        port++;
        printf("%d\n", arr[k]);
    }
    while (1)
    {
       loop :
        printf("select the group-- ");
         while (!(cin >> g)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Enter a number: ";
    }
        
        
      if(g>=0 && g<j)
         port=arr[g];
         
      else{
         printf("idiot enter valid group Number\n");
         goto loop;}

        // return 0;

        // !!! If test requires, make these configurable via args
        //

        // const int delay_secs = 1;
        const char *message = "Hello, World! we are connected to\nmulticast group......... ";

        // create what looks like an ordinary UDP socket
        //
        int fd = socket(AF_INET, SOCK_DGRAM, 0);
        if (fd < 0)
        {
            perror("socket");
            return 1;
        }

        // set up destination address
        //

        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        // addr.sin_addr.s_addr = inet_addr(group);
        // addr.sin_addr.s_addr=inet_ntoa(ip);
        addr.sin_addr.s_addr = inet_addr(ip);
        addr.sin_port = htons(port);

        // std::cout<<"IP addrs">>ip<<std::endl;
        //  now just sendto() our destination!
        //
        char *arr1[10];
        char ch = 0;
        int p[10];
        char msgbuf[MSGBUFSIZE];
        int addrlen = sizeof(addr);
        int nbytes = sendto(fd, message, strlen(message), 0, (struct sockaddr *)&addr, sizeof(addr));
        int l = 0;
        for (i = 0; i < 10; i++)
        {
            l++;
            printf("%d ", l);
            t_out.tv_sec = 1;

            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); // Enable the timeout option if client does not respond

            recvfrom(fd, msgbuf, MSGBUFSIZE, 0, (struct sockaddr *)&addr, (socklen_t *)&addrlen);
            t_out.tv_sec = 4;
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); // Disable the timeout option

            char *connect_ip = inet_ntoa(addr.sin_addr);
            int port1 = ntohs(addr.sin_port);

            arr1[i] = connect_ip;

            p[i] = port1;

            
            addr.sin_addr.s_addr = 0;
            addr.sin_port = 0;
            printf("%s,%d\n", arr1[i], p[i]);
        }
        msgbuf[nbytes];
         //puts(msgbuf);
        printf("%s\n", message1);

        if (nbytes < g)
        {
            perror("--- sender deactivated ---"); // send to
            return 1;
        }

        // sleep(delay_secs * 0); // Unix sleep is seconds
    }
}
mclient1::~mclient1()
{
}


#include "../Header/udp_server.h"
#include "../Header/udp_ServerProperty.h"



int udp_Multicast::Group(){
   
    cout<<"\nENTER THE NUMBER OF GROUP TO BR CREATED:\n";
    cin>>groupNum;
        if(groupNum==0){
            cout<<"WRONG CHOICE: Number of group can a number more than zero\n";
          Group();}
        
         return groupNum; 
    }

     int udp_Multicast::groupChoice(){
       cout<<"Enter the group from 1 to "<<groupNum<<" in which you want to Multicast:"<<endl;
       cin>>grp;
       if(grp==0)
       {
        cout<<"WRONG CHOICE: Choose a created group\n";
        groupChoice();

       }
       
       return grp;
    


     }   

void udp_Multicast::sendReceiveData(int* udpSocket,int g){

   
    cout<<"In sendrecer:";
    ifstream files;
    string *line;
    int BUFF_SIZE;
    line =new string;
    int member;
    IP=new char[INET_ADDRSTRLEN];
   // IP=new char[INET_ADDRSTRLEN];
    try{
    files.open("../ResourceFiles/config.config");
    while(getline(files, *line)){
        istringstream sin(line->substr(line->find("=")+1));
        if(line->find("MulticastIP")!=-1){
         sin>>IP;
        }
        else if(line->find("MemberInGroup")!=-1){
        sin>>member;
        }
    }}
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    socklen_t clientAddrLen, serverAddrLen;


    memset(&server_addr, '\0', sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(g);
    cout<<g<< endl;
    server_addr.sin_addr.s_addr=inet_addr(IP);

   // inet_pton(AF_INET, IP, &(client_addr.sin_addr));
    //inet_ntop(AF_INET, &(client_addr.sin_addr), IP, INET_ADDRSTRLEN);
   // memset(&client_addr, 0, sizeof(client_addr));
    
    cout<<"BUFF SIZE IS:"<<BUFF_SIZE<<endl;
    char buff[BUFF_SIZE];
    int frame_id=0;
    Frame frame_send;
    Frame frame_recv;
    int ack_recv=1;
    socklen_t addr_size;
    int f_recv_size;
    // struct memory allocation:
 
   while (1){
     
       cout<<"Enter Data: ";
            scanf("%s", buff);
        if(ack_recv==1){
            frame_send.sq_no=frame_id;
            frame_send.frame_type=1;
            frame_send.ack=0;            
            strcpy(frame_send.packet.data, buff);
            sendto(*udpSocket, &frame_send, sizeof(Frame), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
            cout<<"->Frame send\n";
        }
       addr_size=sizeof(server_addr);
     int k=0;
    for(int i=0; i<member;i++){
        k++;
        cout<<k<<endl;
        time_out.tv_sec = 1;
          setsockopt(*udpSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&time_out, sizeof(struct timeval)); // Enable the timeout option if client does not respond
        f_recv_size=recvfrom(*udpSocket, &frame_recv, sizeof(frame_recv), 0, (struct sockaddr*)&server_addr, &addr_size);
              if(f_recv_size>0 && frame_recv.sq_no==0 && frame_recv.ack==frame_id+1){
               cout<<"->Ack Received: "<<endl;
               ack_recv=1;
              }
              else{
               cout<<"->Ack Not Received: "<<endl;
               ack_recv=0;
             }
        time_out.tv_sec = 0;
            setsockopt(*udpSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&time_out, sizeof(struct timeval)); // Disable the timeout option

            char *connect_ip = inet_ntoa(server_addr.sin_addr);
            int port1 = ntohs(server_addr.sin_port);
             address[i] = connect_ip;

             p[i] = port1;
            server_addr.sin_addr.s_addr = 0;
            server_addr.sin_port = 0;
            cout<<address[i]<<endl<<p[i]<<endl;
    }
            cout<<"choose any one from above---> "<<endl;
        int v=0;
        const char *message2="hello!";
        cin>>v;
        for(int i=0;i<member;i++){
        if(v==i)
        {
        server_addr.sin_addr.s_addr = inet_addr(IP);
        server_addr.sin_port = htons(p[i]);
        sendto(*udpSocket, message2, strlen(message2), 0, (struct sockaddr *)&server_addr, sizeof(server_addr));
        cout<<"length of message=";
        cout<<"message send"<<strlen(message2);
        cout<<"\n";
        }
        }
         
        if (f_recv_size< groupNum)
        {
            perror("--- sender deactivated ---"); // send to
         //   return 1;
        }
            

    
        frame_id++;
    }
    close(*udpSocket);
}



// for releasing port number. if client or server unexpectedly closes application.
/*void udp_Broadcast::signal_Handler(int signal){
    if(signal==SIGINT){
        cout<<"====> EXITING <===="<<signal;
      //  close(*udpSocket);
    }
    exit(1);
}*/


int udp_Multicast::createSocket(){
    

    udpSocket=new int;
    *udpSocket=socket(AF_INET, SOCK_DGRAM,IPPROTO_UDP);
    if(*udpSocket<0){
        cout<<"\tSorry socket creation failed: "<<endl;
        exit(1);
    }else
        cout<<"\tsocket created successfully: "<<endl;
        bindSocket(udpSocket);
    return 0;    
}

void udp_Multicast::bindSocket(int* udpSocket){
    cout<<"socket in before calling BInd function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
   // createSocket(udpSocket);
    cout<<"socket in after calling cresocket function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
    /*if(setsockopt(*udpSocket, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) <0)
    {
    
        perror("socket set error...\n");
        exit(-1);
    }*/


    ifstream files;
    string line;
   // cout<<"socket address in bind is: "<<udpSocket<<endl;
    try
    {
        files.open("../ResourceFiles/config.config");
        while (getline(files, line))
        {
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("MulticastPort")!=-1){
                sin>>portNumber;
            }
        }   
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }



    

    //inet_pton(AF_INET, IP, &(client_addr.sin_addr));
    //inet_ntop(AF_INET, &(client_addr.sin_addr), IP, INET_ADDRSTRLEN);

    Group();
    int groupOnPort[groupNum];
    for(int i = 0; i<groupNum; i++)
    {
       groupOnPort[i] = portNumber;
       cout<<"Group created on port number :"<<portNumber<<endl;
       portNumber++;
       
    }
    groupChoice();

    
    
    
    
    /*if(bind(*udpSocket, (struct sockaddr*)&server_addr, sizeof(server_addr))<0){
        cerr<<"\t Error while binding: "<<endl;
        close(*udpSocket);
        exit(-1);
    }
    else{
        cout<<"\t Server Binded successfully: "<<endl;
    }*/

  
    sendReceiveData(udpSocket,groupOnPort[grp-1]);
}
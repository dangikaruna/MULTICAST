#include "../Header/udp_server.h"
void UDP_Server::selectOperation(){
    cout<<"\t1. UDP UNICAST"<<endl;
    cout<<"\t2. UDP MULTICAST"<<endl;
    cout<<"\t3. UDP BROADCAST"<<endl;
    cout<<"\t0. Get out"<<endl;
}
void UDP_Server::Driver(){
    int input;
    udp_unicast unicast;            // object of udp_unicast class
    udp_Multicast multicast;        // object of udp_Multicast class
    udp_Broadcast broadcast;        // object of udp_Broadcast class
    do{
    selectOperation();
    cin>>input;
    switch(input){
        
        case 1:
            cout<<"\t\t    UDP---UNICAST "<<endl;
            unicast.udpUnicast();
            unicast.~udp_unicast();
            break;
        case 2:
            cout<<"\t\t     UDP---MULTICASTING "<<endl;
            multicast.udpMulticast();
            multicast.~udp_Multicast();
            break;
        case 3:
            cout<<"\t\t     UDP---BROADCASTING "<<endl;
            broadcast.udpBroadcast();
            broadcast.~udp_Broadcast();
            break;
        case 0:
            cout<<"\t\t     APPLICATION CLOSED "<<endl;
            exit(1);
            break;
        default:
            cout<<"Wrong choice: "<<endl;
            break;
    }}
    while(input!=0); 
}

// Unicasting
udp_unicast::udp_unicast(){}   

void udp_unicast::udpUnicast(){

    udp_unicast::createSocket();
}
udp_unicast::~udp_unicast(){}
//unicasting section ends here

// Multicasting section starts
udp_Multicast::udp_Multicast(){}
void udp_Multicast::udpMulticast(){
udp_Multicast::createSocket();

}
udp_Multicast::~udp_Multicast(){}
// Multicasting section ends here.

//Broadcasting section starts
udp_Broadcast::udp_Broadcast(){}
void udp_Broadcast::udpBroadcast(){
    //cout<<"in broadcast section in driver.cpp\n";
    udp_Broadcast::createSocket();
}
udp_Broadcast::~udp_Broadcast(){}
//Broadcasting section ends here.
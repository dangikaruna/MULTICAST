#include "../Header/udp_server.h"

// for releasing port number. if client or server unexpectedly closes application.
void udp_unicast::signal_Handler(int signal){
    if(signal==SIGINT){
        cout<<"====> EXITING <===="<<signal;
      //  close(*udpSocket);
    }
    exit(1);
}

void udp_unicast::sendFrame(int* udpSocket, struct sockaddr_in *server, struct sockaddr_in *client){
    int frame_id=0;
    Frame frame_recv;
    Frame frame_send;
    char *buff;
    ifstream files;
    string line;
    int *BUFF_SIZE;
    BUFF_SIZE=new int;
    int *status;
    status=new int;
    *status=1;
    try{
        files.open("../ResourceFiles/config.config");
        while(getline(files, line)){
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("BUFF_SIZE")!=-1){
                sin>>*BUFF_SIZE;
            }}}
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    cout<<"BUFF size is: "<<*BUFF_SIZE<<endl;
    buff=new char[*BUFF_SIZE];
    socklen_t addr_size;
    addr_size=sizeof(*client);
    while(1){
        cout<<"Server is receiving: "<<endl;

        int f_recv_size=recvfrom(*udpSocket, &frame_recv, sizeof(Frame),0, (struct sockaddr*)client, &addr_size);
        if(f_recv_size>0 && frame_recv.frame_type==1 && frame_recv.sq_no==frame_id){
            cout<<"Frame Coming from IP & PORT NUMBER: "<<inet_ntoa(client->sin_addr)<<" "<<(int)htons(client->sin_port)<<" --->Frame id is: "<<frame_id<<"-->Frame Received: "<<frame_recv.packet.data<<endl;
            frame_send.sq_no=0; 
            frame_send.frame_type=0;
            frame_send.ack=frame_recv.sq_no+1;
            sendto(*udpSocket, &frame_send, sizeof(frame_send),0,(struct sockaddr* )client, addr_size);
            cout<<"ACK send\n";
        }
        else{
            cout<<"->Frame not received: "<<endl;
        }
        frame_id++;
    }
}

void udp_unicast::sendReceiveData(int *udpSocket){}

//creating socket.
int udp_unicast::createSocket(){
    udpSocket=new int;
    *udpSocket=socket(AF_INET, SOCK_DGRAM,IPPROTO_UDP);
    if(*udpSocket<0){
        cout<<"\tSorry socket creation failed: "<<endl;
        exit(1);
    }else
        cout<<"\tsocket created successfully: "<<endl;
        bindSocket(udpSocket);
    return 0;    
}
void udp_unicast::bindSocket(int* udpSocket){
    cout<<"socket in before calling BInd function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
   // createSocket(udpSocket);
    cout<<"socket in after calling cresocket function is: "<<"value is: "<<*udpSocket<<"address is: "<<udpSocket<<endl;
    ifstream files;
    string line;
   // cout<<"socket address in bind is: "<<udpSocket<<endl;
    try
    {
        files.open("../ResourceFiles/config.config");
        while (getline(files, line))
        {
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("port")!=-1){
                sin>>portNumber;
            }
        }   
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(portNumber);
    server_addr.sin_addr.s_addr=INADDR_ANY;
    
    if(bind(*udpSocket, (struct sockaddr*)&server_addr, sizeof(server_addr))<0){
        cerr<<"\t Error while binding: "<<endl;
        close(*udpSocket);
        exit(-1);
    }
    else{
        cout<<"\t Server Binded successfully: "<<endl;
    }
   sendFrame(udpSocket, &server_addr, &client_addr);
}


/*
void selectOperation(){
    cout<<"\t1. UDP UNICAST"<<endl;
    cout<<"\t2. UDP MULTICAST"<<endl;
    cout<<"\t3. UDP BROADCAST"<<endl;
    cout<<"\t0. Get out"<<endl;
}
void Driver(){
    int input;
    udp_unicast unicast;            // object of udp_unicast class
    udp_Multicast multicast;        // object of udp_Multicast class
    udp_Broadcast broadcast;        // object of udp_Broadcast class
    do{
    selectOperation();
    cin>>input;
    switch(input){
        case 1:
            cout<<"\t\t    UDP---UNICAST "<<endl;
            unicast.udpUnicast();
            unicast.~udp_unicast();
            break;
        case 2:
            cout<<"\t\t     UDP---MULTICASTING "<<endl;
            multicast.udpMulticast();
            multicast.~udp_Multicast();
            break;
        case 3:
            cout<<"\t\t     UDP---BROADCASTING "<<endl;
            broadcast.udpBroadcast();
            broadcast.~udp_Broadcast();
            break;
        case 0:
            cout<<"\t\t     APPLICATION CLOSED "<<endl;
            exit(1);
            break;
        default:
            cout<<"Wrong choice: "<<endl;
            break;
    }}
    while(input!=0);   
}
*/

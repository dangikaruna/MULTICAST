#include "../Header/udp_Client.h"



void UDP_Client::selectOperation(){
    std::cout<<"\t\t 1. CLIENT_UNICAST: "<<std::endl;
    std::cout<<"\t\t 2. CLIENT MULTICAST: "<<std::endl;
    std::cout<<"\t\t 3. CLIENT BROADCAST: "<<std::endl;
}
void UDP_Client::Driver(){
    int choice;
     udp_ClientUnicast clientUnicast;
     udp_ClientMulticast clientMulticast;
     udp_ClientBroadCast clientBroadcast;
    do{
        selectOperation();
        std::cin>>choice;
        std::cout<<std::endl;
        switch (choice)
        {   
        case 1:
            std::cout<<"\t\t  CLEINT UNICAST: "<<std::endl;
            clientUnicast.udpClientUnicast();
            clientUnicast.~udp_ClientUnicast();
            break;
        case 2:
            std::cout<<"\t\t  CLIENT MULTICAST: "<<std::endl;
            clientMulticast.udpClientMulticast();
            clientMulticast.~udp_ClientMulticast();;
            break;
        case 3:
            std::cout<<"\t\t  CLIENT BROADCASR: "<<std::endl;
            clientBroadcast.udpClientBroadCast();
            clientBroadcast.~udp_ClientBroadCast();
        case 4:
            std::cout<<"\t\t GET OUT: "<<std::endl;
            exit(1);
        default:
            std::cout<<"\t\t WRONG CHOICE: "<<std::endl;
            exit(1);
            break;
        }
    }while ((choice!='0'));
}


// UNICASTINGNGGGGG
void udp_ClientUnicast::udpClientUnicast(){
    udp_ClientUnicast::createSocket();
}
udp_ClientUnicast::udp_ClientUnicast(){}
udp_ClientUnicast::~udp_ClientUnicast(){}



//MULTICASTINGGGGG
udp_ClientMulticast::udp_ClientMulticast(){}
void udp_ClientMulticast::udpClientMulticast(){
     udp_ClientMulticast::createSocket();
}
udp_ClientMulticast::~udp_ClientMulticast(){}


//BROADCASTTTINGNGGG
udp_ClientBroadCast::udp_ClientBroadCast(){}
void udp_ClientBroadCast::udpClientBroadCast(){
     udp_ClientBroadCast::createSocket();

}
udp_ClientBroadCast::~udp_ClientBroadCast(){}
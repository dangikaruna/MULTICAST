#include "../Header/udp_Client.h"
#include "../Header/udp_ClientProperty.h"

//UNICASTINGNGGGGGG
int udp_ClientMulticast::createSocket(){
    udpClientSocket=new int;
    *udpClientSocket=socket(AF_INET, SOCK_DGRAM, 0);
    if(*udpClientSocket<0){
        std::cout<<"SOCKET CREATION FAILED: "<<std::endl;
    }
    else{
        std::cout<<"Socket created successfully:"<<std::endl;
    }
    std::cout<<"Socket address in createSocket: "<<udpClientSocket<<std::endl;
    sendReceiveData(udpClientSocket);
    return 0;
}
void udp_ClientMulticast::sendReceiveData(int* udpClientSocket){
    cout<<"In sendrecer:";
     // fd, SOL_SOCKET, SO_REUSEADDR, (char*) &yes, sizeof(yes)
     if(setsockopt(*udpClientSocket, SOL_SOCKET, SO_REUSEADDR, &multicast, sizeof(multicast)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }




    ifstream files;
    string *line;
    int BUFF_SIZE;
    line =new string;
    IP=new char[INET_ADDRSTRLEN];
    try{
    files.open("../ResourceFiles/config.config");
    while(getline(files, *line)){
        istringstream sin(line->substr(line->find("=")+1));
        if(line->find("MulticastPort")!=-1){
            sin>>portNumber;
        }else if(line->find("BUFF_SIZE")!=-1){
            sin>>BUFF_SIZE;
        }
       else if(line->find("MulticastGroup")!=-1){
            sin>>IP;
        }
    }}
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    socklen_t clientAddrLen, serverAddrLen;

   // inet_pton(AF_INET, IP, &(client_addr.sin_addr));
    //inet_ntop(AF_INET, &(client_addr.sin_addr), IP, INET_ADDRSTRLEN);
   // memset(&client_addr, 0, sizeof(client_addr));
    memset(&server_addr, '\0', sizeof(server_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(portNumber);
    server_addr.sin_addr.s_addr= htonl(INADDR_ANY);
     
     if((bind(*udpClientSocket, (struct sockaddr*)&server_addr, sizeof(server_addr))) < 0) {
    perror("binding error...\n");
    exit(-1);
  }

   struct ip_mreq mreq;
    mreq.imr_multiaddr.s_addr = inet_addr(IP);
    mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    if(setsockopt(*udpClientSocket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*) &mreq, sizeof(mreq)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }



    cout<<"BUFF SIZE IS:"<<BUFF_SIZE<<endl;
    char buff[BUFF_SIZE];
    int frame_id=0;
    Frame frame_send;
    Frame frame_recv;
    int ack_recv=1;
    socklen_t addr_size;
    // struct memory allocation:
 
   while (1){
              cout<<"client is receiving multicast: "<<endl;

        int f_recv_size=recvfrom(*udpClientSocket, &frame_recv, sizeof(Frame),0, (struct sockaddr*)&client_addr, &addr_size);
    
        if(f_recv_size>0 && frame_recv.frame_type==1 && frame_recv.sq_no==frame_id)
        {
            cout<<"Frame Coming from IP & PORT NUMBER: " << &client_addr <<" "<<addr_size<<" --->Frame id is: "<<frame_id<<"-->Frame Received: "<<frame_recv.packet.data<<endl;
            frame_send.sq_no=0; 
            frame_send.frame_type=0;
            frame_send.ack=frame_recv.sq_no+1;
            sendto(*udpClientSocket, &frame_send, sizeof(frame_send),0,(struct sockaddr* )&client_addr, addr_size);
            cout<<"ACK send\n";
        }
        else{
            cout<<"->Frame not received: "<<endl;
        }
        frame_id++;





       /*cout<<"Enter Data: ";
            scanf("%s", buff);
        if(ack_recv==1){
            frame_send.sq_no=frame_id;
            frame_send.frame_type=1;
            frame_send.ack=0;            
            strcpy(frame_send.packet.data, buff);
            sendto(*udpClientSocket, &frame_send, sizeof(Frame), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
            cout<<"->Frame send\n";
        }
       addr_size=sizeof(server_addr);
        int f_recv_size=recvfrom(*udpClientSocket, &frame_recv, sizeof(frame_recv), 0, (struct sockaddr*)&server_addr, &addr_size);

        if(f_recv_size>0 && frame_recv.sq_no==0 && frame_recv.ack==frame_id+1){
            cout<<"->Ack Received: "<<endl;
            ack_recv=1;
        }
        else{
            cout<<"->Ack Not Received: "<<endl;
            ack_recv=0;
        }
        frame_id++;*/
    }
    close(*udpClientSocket);
}
